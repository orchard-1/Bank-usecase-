<?php
    #function Customer Login
    function customer_login(){
        $account_number=readline("\nEnter Account_Number :");
        $password=readline("\nEnter Your Password :");
        $obj=validate_customer($account_number,$password);
            if($obj){
                echo "\nHello....! ".$obj->getName(); 
                echo "\n Login Successful";   
                return $obj;
            }
        return false;
    }
    
    #validate Customer credentials ()
    function validate_customer($account_number,$password){
        foreach(Bank::$Customers as $obj){
            if($obj->getAccount_number()==$account_number && $obj->getPassword()==$password){
                return $obj;
            }
        }
        return false;
    }
?>