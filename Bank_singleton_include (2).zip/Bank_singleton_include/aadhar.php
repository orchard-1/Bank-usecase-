 <?php
    #validate aadhar
    function validate_aadhar(){
        $aadhar=0;
        $count=0;
        do{
            if($count==0){
                $aadhar=readline("\nEnter Aadhar number : ");
                $count++;
            }else{
                $aadhar=readline("\nEnter A valid Aadhar number : ");
            }
        
        }while(!preg_match('/[2-9]{1}[0-9]{9}/', $aadhar));
        return $aadhar;
    }
?>