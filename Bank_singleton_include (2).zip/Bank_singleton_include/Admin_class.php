<?php
# start of Admin Class

class Admin{ 
    private $admin_name="chinmaya";
    private $password="1234";
    
    #varaiable to hold the object/instance
    private static $instance;

      # restricting from accessing outside of class
    private function __construct(){
     
    }
    #function to acess constructor
    public static function create_object(){
        if(!isset(self::$instance)){
            self::$instance = new Admin();
        }
        return self::$instance;
    }

    # Get the value of Admin password
     public function getPassword()
    {
        return $this->password;
    }
    
    # Set the value of password
    public function setPassword($password)
    {
        $this->password = $password;
    }
    
    # Get the value of admin_name
    public function getAdmin_name()
    {
        return $this->admin_name;
    }

    # Set the value of admin_name
    public function setAdmin_name($admin_name)
    {
        $this->admin_name = $admin_name;
    }
    # remove customer
    function remove_customer(){
        $account_number=readline("Enter customer Account no : ");
        $customer_found=0;
        foreach(Bank::$Customers as $obj){
            if($obj->getAccount_number()==$account_number){
                $obj->setAccount_number(-1);
                echo "removed Account A/c no :$account_number";
                break;  
            }
        }
        
    }
    
    # function to update customer 
    function update_customer(){
        $account_number=readline("Enter Customers Account Number : ");
        $account_found=0;
        foreach(Bank::$Customers as $obj){
            if($obj->getAccount_number()==$account_number ){
                $account_found=1;
                echo "======== UPADTING MOBILE NUMBER ==========";
                $mobile=validate_mobile();  
                $obj->setMobile($mobile);
                echo "Successfully updated mobile number";
             }
        }
        if($account_found==0){
            echo "No Account Found\nEnter valid account Number";
        }
    }
    #start of add_customer();
    //=========================================================
    function add_customer(){
        $customer_obj=new Customer();
        $name=validate_name();
        $mobile=validate_mobile();
        # balance will be zero fro new account
        $balance=0;
        $aadhar=validate_aadhar();
        $pan=validate_pan();
        $account_number=$aadhar;
        #adding debit card
         $card_num=$aadhar*10000;
         $type="debit";
         $status="Active";
         $customer_obj->set_card($card_num,$type,$status);
         #adding credit card
         $card_num=$aadhar*10000-1;
         $type="credit";
         $status="Active";
         $newstring="$name.$mobile.$aadhar.$pan";
         $unquiestring=uniqid();
         $unquiestring=$unquiestring.$newstring;
         $password=md5($unquiestring);
         $customer_obj->set_card($card_num,$type,$status);
         $customer_obj->setName($name);
         $customer_obj->setAadhar($aadhar);
         $customer_obj->setAccount_number($account_number);
         $customer_obj->setMobile($mobile);
         #type of account
         $type_of_account=readline("\nEnter type of account : ");
         $customer_obj->setType_of_account($type_of_account);
         $customer_obj->setPan($pan);
         $customer_obj->setBalance($balance);
         $customer_obj->setPassword($password);
         #pushing customer object to the array in Bank Class
         Bank::push($customer_obj);      
    }
    # start of set_minmum_balance()
    function set_minmum_balance(){
        $minmum_avarage_balance=null;
        $minmum_avarage_balance=readline("Enter MAB :");
        Bank::$minmum_avarage_balance=$minmum_avarage_balance;
        echo "Successfully Updated MAB rate\n";
        echo "Current MAB  is $minmum_avarage_balance";
    }
    //===================================
    #fuction for viewing customer
    function view_profile(){
        $account_number=readline("Enter account Number : ");
        foreach(Bank::$Customers as $obj){
            if($obj->getAccount_number()==$account_number){
                echo "\nDetails of the user with A/c no : $account_number are:\n";
                echo "==============================\n Name : ".$obj->getName()."\n";
                echo "\n Account type : ".$obj->getType_of_account();
                echo "\n==============================\n"; 
                echo "\n Mobile : ".$obj->getMobile();
                echo "\n==============================\n"; 
                echo "\n Balance : ".$obj->getBalance();
                echo "\n==============================\n"; 
                echo "\n Aadhar : ".$obj->getAadhar();
                echo "\n==============================\n"; 
                echo "\n PAN : ".$obj->getPan();
                echo "\n==============================\n"; 
                echo "=========== CARDS ===========\n";
                    foreach($obj->cards as $card => $value){
                        echo "Card NUmber : ".$card."\n";
                        echo "Type : ".$value["type"]."\n";
                        echo "Status :".$value["status"]."\n";
                        echo "===================================\n";
                    }
            }else{
                   echo "Invalid Account number ";
                }   
        }
    }

     # start of set_intrest_rate()
    function set_intrest_rate(){
        $intrest_rate=readline("Enter Intrest rate :");
        Bank::$intrest_rate=$intrest_rate;
        echo "Successfully Updated Intrest Rate rate\n";
        echo "Current Intrest Rate  is $intrest_rate";
    }

}

    # end of Admin class
?>