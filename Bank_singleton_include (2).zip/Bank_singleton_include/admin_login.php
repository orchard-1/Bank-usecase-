<?php
     #function for Admin login
    function admin_login(){
        $admin_name=readline("Enter Admin User_name : ") ;
            if(validate_admin_name($admin_name)){
                 $password=readline("Enter Admin password : ") ;
                    if(validate_password($password)){
                        echo "\nHello $admin_name.....\nsucessfully logged in\n";
                        return 1;
                    }
            }
        return 0;
    } 
    // end of admin_login()
    #=============================================================
       # function to check validity of username(Admin)
    function validate_admin_name($username){
       // $admin_obj=new Admin();  
        if($GLOBALS['admin_obj']->getAdmin_name()==$username){
        return true;
        }else{
            return false;
        }
    }
    # end of validate_customername()
    // ==================================
    # function to check validity of password(Admin)
    function validate_password($password){
      #  $admin_obj=new Admin();  
        if($GLOBALS['admin_obj']->getPassword()==$password){
            return true;
        }
            return false;
    }
    
    # end of validate_password()
?>