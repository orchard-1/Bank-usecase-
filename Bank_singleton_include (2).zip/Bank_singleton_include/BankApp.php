<?php
require "Admin_class.php";
require "Bank_class.php";
require "Customer_class.php";
require "admin_login.php";
require "customer_login.php";
require "name.php";
require "mobile.php";
include "pan.php";
include "aadhar.php";




# driver block

    # function to get display menu
    function get_menu(){
        echo "\n=========== MAIN MENU ===============";
        echo "\n1.Admin\n2.Customer\n";
    }

    # function for customer menu
    function get_customer_menu(){
        echo "\n=========== CUSTOMER MENU ===============\n";
        echo "1.DEPOSIT\n2.WITHDRAW\n3.BALANCE_INQUIRY\n4.PROFILE";
        echo "\n5.CHANGE_CARD_STATUS\n6.Change Password\ ";
    }
    
    #creating admin menu
    function get_admin_menu(){
        echo"\n=========== ADMIN MENU ===============";
        echo "\n1.ADD CUSTOMER\n2.VIEW CUSTOMER\n";
        echo "3.UPDATE\n4.REMOVE\n5.setMAB\n6.set Intrest Rate\n";
    }

    #function for Customer operations
    function customer_operations($choice,$obj){
    
        switch($choice){
            
            case 1:$obj->deposit();
                    break;
            case 2:$obj->withdraw();
                    break;
            case 3:echo "Available balance is :".$obj->getBalance();    
                    break;    
            case 5: $obj->change_card_status();
                    break;
            case 6:  $obj->reset_password();
                    break;  
            case 4: $obj->my_profile();
                    break;               
            case "exit": echo "\nExited from Customer\n";
                    break; 
            default : echo "\nChoose a Valid Option from Customer MENU";
                    break; 
        }
    }

 
    //==========================================================
    
    #creating admin_operations
    function admin_operations($choice){
       // $admin_obj=new Admin();
       $admin_obj=$GLOBALS['admin_obj'];
        switch($choice){
    
            case 1: $admin_obj->add_customer();
                    break;
            case 2: $admin_obj->view_profile();
                    break;  
            case 3: $admin_obj->update_customer();
                    break; 
            case 4: $admin_obj->remove_customer();
                    break;                    
            case 5: $admin_obj->set_minmum_balance();
                    break;
            case 6: $admin_obj->set_intrest_rate();       
                    break;
            case "exit": echo "\nExited from Admin\n";   
                    break;
            default : echo "Enter a valid option from Admin menu\n";     
        }

    }
    #end of admin_operations();
 
//============================================================
#start of logic
$option=0;
$admin_obj=Admin::create_object();
echo "\n====================== BANK APPLICATION =========================";
do{
    get_menu();
    # take option from user
    $option=readline("Enter your option : ");
    switch($option){
        case 1: 
                 if(admin_login()){
                    $choice;
                    do{
                    get_admin_menu(); 
                    $choice=readline("\nchoose your Admin option : ");
                        admin_operations($choice);
                    }while($choice!="exit");
                 }else{
                     echo "Invalid Admin Credentials";
                 }
                break;
        case 2: $obj=customer_login();
                if($obj){
                 $choice;
                 do{
                     get_customer_menu(); 
                     $choice=readline("\nchoose your Customer option : ");
                      customer_operations($choice,$obj);
                }while($choice!="exit");
                }else{
                    echo "Invalid Customer credentials";
                } 
                break;
        case "exit": echo "\nyou are exited from the Bank App\nThank you....!!\n";      
                break;
        default: echo "Choose Valid option from the MENU";
                break;            
    }

}while($option!="exit");



?>