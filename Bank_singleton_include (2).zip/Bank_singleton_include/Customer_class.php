<?php
    class Customer{
        private $name;
        private $mobile;
        private $balance;
        private $aadhar;
        private $pan;
        private $account_number;
        private $password;
        private $type_of_account;
        public  $cards=array();
        

        public function getType_of_account()
        {
            return $this->type_of_account;
        }
    
        public function setType_of_account($type_of_account)
        {
            $this->type_of_account = $type_of_account;

            return $this;
        }

        #function for deposit()
        function deposit(){

            $amount=readline("Enter amount to deposit : ");
            $cuurent_balance=$this->getBalance();
            echo "current balace is ".$this->getBalance()."\n";
            $this->setBalance($cuurent_balance+$amount);
            echo "updated balace is ".$this->getBalance()."\n";
        }

        #function for withDraw()
        function withdraw(){
            $amount=readline("Enter amount to Withdraw : ");
            $cuurent_balance=$this->getBalance();
            echo "current balace is ".$this->getBalance()."\n";
            if($amount<=$cuurent_balance){
                $this->setBalance($cuurent_balance-$amount);
                echo "updated balace is ".$this->getBalance()."\n";
            }else{
                echo "Insufficient Funds...!\nAvailable : $cuurent_balance";
            }
        }

        #function to disable/enable the card
        function change_card_status(){
            $cardfound=0;
            $card_num=readline("Enter card Number : ");
            $type=readline("Enter type :");
            $cardfound=0;
        
            foreach($this->cards as $card=>$value){
                if($card==$card_num && $value["type"]==$type){
                    $cardfound=1;
                    if($value["status"]=="Active"){
                    $this->set_card($card_num,$type,"InActive");
                    echo "Suceessfully disabled $card_num";
                    break;
                } else{
                        $card["status"]="Active";
                        echo "Suceessfully Activated $card_num";
                        break;
                    }
            
                }
            }
        
            if($cardfound==0){
                echo "Invalid card Details";
            }
        }

        #function to change password
        function reset_password(){
        $current_password=readline("Enter the Current password : "); 
            if($current_password==$this->getPassword()){
                $new_password=readline("Enter new password : ");
                $this->setPassword($new_password);
                echo "Password Reset Successful";
            }else{
                echo "Incorrect password..!";
            }

        }
        //==========================================================
        function my_profile(){
            echo "\nAccount A/c no : ".$this->getAccount_number()."\n";
            echo "==============================\n Name : ".$this->getName()."\n";
            echo "\n Account type : ".$this->getType_of_account();
            echo "\n==============================\n"; 
            echo "\n Mobile : ".$this->getMobile();
            echo "\n==============================\n"; 
            echo "\n Balance : ".$this->getBalance();
            echo "\n==============================\n"; 
            echo "\n Aadhar : ".$this->getAadhar();
            echo "\n==============================\n"; 
            echo "\n PAN : ".$this->getPan();
            echo "\n==============================\n"; 
            echo "=========== CARDS ===========\n";
            foreach($this->cards as $card => $value){
                echo "Card NUmber : ".$card."\n";
                echo "Type : ".$value["type"]."\n";
                echo "Status :".$value["status"]."\n";
                echo "===================================\n";
            }
        }

        # adding card to customer 
        function set_card($card_num,$type,$status){
            $this->cards[$card_num]=array("type"=>$type,"status"=>$status);
        }

        #changind status of card
        function set_status($card_num,$type,$status){
            $this->cards[$card_num]["status"]=$status;
        }

        # Get the value of name
        public function getName()
        {
            return $this->name;
        }
    
        # Set the value of name
        public function setName($name)
        {
            $this->name = $name;
        }

        # Get the value of mobile
        public function getMobile()
        {
            return $this->mobile;
        }

        # Set the value of mobile
    
        public function setMobile($mobile)
        {
            $this->mobile = $mobile;
        }

        #Get the value of balance
        public function getBalance()
        {
            return $this->balance;
        }
        # Set the value for balance
        public function setBalance($balance)
        {
            $this->balance = $balance;
        }

        # Get the value of aadhar
        public function getAadhar()
        {
            return $this->aadhar;
        }

        #set the value of aadhar
        public function setAadhar($aadhar)
        {
            $this->aadhar = $aadhar;

        }
        
        # Get the value of pan
        public function getPan()
        {
            return $this->pan;
        }

        # Set the value of pan
        public function setPan($pan)
        {
            $this->pan = $pan;
        }

        # Get the value of account_number
        public function getAccount_number()
        {
            return $this->account_number;
        }

        # Set the value of account_number
        public function setAccount_number($account_number)
        {
            $this->account_number = $account_number;
        }
        
        # Get the value of password
        public function getPassword()
        {
            return $this->password;
        }

        # Set the value of password
        public function setPassword($password)
        {
            $this->password = $password;
        }
    }

    #end of Customer class
    // =========================================================
 ?>