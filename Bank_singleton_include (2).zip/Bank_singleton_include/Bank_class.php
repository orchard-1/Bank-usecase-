<?php
    //==========================================================
    # start of Bank Class

    class Bank{
        public const BANK_NAME ="HDFC"; 
        public $ifsc="HDFC0001636";
        public $address="6-5-34,\n OPP. PUJITHA APARTMENT \nHYDERABAD ROAD,\n TELANGANA ";
        public static $Customers= array();
        public static $minmum_avarage_balance;
        public static $intrest_rate;
            static function push($customer_obj){
                array_push(Bank::$Customers,$customer_obj);
                echo "\n==========================================================\n";
                echo "Successfully added Customer ". $customer_obj->getName();
                echo "\npassword :".$customer_obj->getPassword();
                echo "\n==========================================================\n";
            }

    }
?>